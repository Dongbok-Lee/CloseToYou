-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11b201.p.ssafy.io    Database: closetoyou2
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `closets`
--

DROP TABLE IF EXISTS `closets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `closets` (
  `closet_id` bigint NOT NULL AUTO_INCREMENT,
  `closet_code` varchar(255) DEFAULT NULL,
  `created_date_time` datetime(6) DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `updated_date_time` datetime(6) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`closet_id`)
) ENGINE=InnoDB AUTO_INCREMENT=227 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `closets`
--

LOCK TABLES `closets` WRITE;
/*!40000 ALTER TABLE `closets` DISABLE KEYS */;
INSERT INTO `closets` VALUES (181,'A1B2C3','2024-08-11 16:24:41.000000',_binary '\0','MyCloset','2024-08-11 16:24:41.000000',1),(209,'RRCBHB',NULL,_binary '\0','나의 프론트 옷장','2024-08-13 17:53:33.181518',4),(211,'JMFC6S',NULL,_binary '','다','2024-08-14 11:58:31.186557',16),(212,'A8SVAV',NULL,_binary '\0','안방 옷장','2024-08-15 23:26:50.222750',17),(213,'3UR2NI',NULL,_binary '','마이클 옷장 2','2024-08-14 04:47:02.409682',16),(214,'3ur2ni',NULL,_binary '','테스트','2024-08-14 06:28:08.975118',16),(215,'3UR2NI',NULL,_binary '','테스트옷장','2024-08-14 11:20:59.049834',16),(216,'3UR2NI',NULL,_binary '','테스트','2024-08-14 11:22:08.457444',16),(217,'JMFC6S',NULL,_binary '\0','여름 전용 옷장','2024-08-14 12:19:57.388194',16),(218,'3UR2NI',NULL,_binary '','후','2024-08-14 12:59:41.419413',16),(219,'3UR2NI',NULL,_binary '\0','sadfsaf','2024-08-15 09:18:58.844579',16),(220,'51JCRL',NULL,_binary '','최강팀 옷장','2024-08-15 10:52:19.543452',17),(221,'C90E54',NULL,_binary '','우주뿌셔','2024-08-15 08:47:30.765715',17),(222,'NSR504','2024-08-15 07:41:51.625785',_binary '\0','하퍼의 옷장','2024-08-15 07:41:51.625785',15),(223,'D913PU','2024-08-15 10:53:26.420146',_binary '\0','백옷장','2024-08-15 10:53:26.420146',17),(224,'LGGVGB',NULL,_binary '','1123','2024-08-15 16:20:37.910342',23),(225,'C90E54','2024-08-15 16:33:05.646735',_binary '\0','1234','2024-08-15 16:33:05.646735',24),(226,'JCZPBM','2024-08-15 16:40:03.580178',_binary '\0','1234','2024-08-15 16:40:03.580178',23);
/*!40000 ALTER TABLE `closets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16 11:52:13
