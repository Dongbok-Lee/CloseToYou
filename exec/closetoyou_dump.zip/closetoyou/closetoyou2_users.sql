-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11b201.p.ssafy.io    Database: closetoyou2
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `created_date_time` datetime(6) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL,
  `is_high_contrast` bit(1) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `updated_date_time` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (15,'2024-08-14 01:05:56.177482','hrb.harper@gmail.com',_binary '\0',_binary '\0','하퍼','$2a$10$rSKZPos5a56KIyRjcKKK2.VLvVf.HxX4XaeZ6REmGG5ay/bB01vwe','2024-08-15 19:01:27.939851'),(17,'2024-08-14 01:09:09.143060','forpjt02@gmail.com',_binary '\0',_binary '\0','유진','$2a$10$ejU8KtstrndubrPH2R51De5slKdjHjR6Nw11S59YqrAu5zuxvcHc6','2024-08-16 02:40:49.727649'),(18,'2024-08-14 17:35:12.543853','ssoonice11@kakao.com',_binary '\0',_binary '\0','야호',NULL,'2024-08-15 15:18:27.020371'),(19,'2024-08-15 02:58:21.508890','chpark6851@naver.com',_binary '\0',_binary '\0','박찬호','$2a$10$siPxRzVeb4f566quKGfrkOU4EZCpgUPJFGvPmMRJcR/3t3pAVaDna','2024-08-15 02:58:21.508890'),(20,'2024-08-15 04:49:17.938193','typoon0820@naver.com',_binary '\0',_binary '\0',NULL,NULL,'2024-08-15 04:49:17.938193'),(21,'2024-08-15 04:59:14.685676','typoon0820@gmail.com',_binary '\0',_binary '\0',NULL,NULL,'2024-08-15 04:59:14.685676'),(22,'2024-08-15 05:03:05.759835','leesumin305@gmail.com',_binary '\0',_binary '\0',NULL,NULL,'2024-08-15 05:03:05.759835'),(23,'2024-08-15 05:29:17.399621','kmh940408@gmail.com',_binary '\0',_binary '\0','마이클',NULL,'2024-08-15 19:06:45.622967'),(24,'2024-08-15 15:30:03.403641','oilpott12@naver.com',_binary '\0',_binary '\0','마이클','$2a$10$I370CtcEo9QPGyaVhbKI4e2b2zSO6SgSeARl/6gjdcZz9jCW0i5uC','2024-08-15 19:01:06.376894');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16 11:52:14
