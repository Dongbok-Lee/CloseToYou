-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11b201.p.ssafy.io    Database: closetoyou2
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clothes`
--

DROP TABLE IF EXISTS `clothes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clothes` (
  `clothes_id` bigint NOT NULL AUTO_INCREMENT,
  `color` varchar(255) DEFAULT NULL,
  `created_date_time` datetime(6) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `is_deleted` bit(1) NOT NULL DEFAULT b'0',
  `last_worn_date` date DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `nfc_id` bigint DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `pattern` varchar(255) DEFAULT NULL,
  `season` varchar(255) DEFAULT NULL,
  `size` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `updated_date_time` datetime(6) DEFAULT NULL,
  `wearing_count` int NOT NULL,
  `closet_id` bigint DEFAULT NULL,
  PRIMARY KEY (`clothes_id`),
  KEY `FKoj7jm8jqriqywdmxf4xkw6et2` (`closet_id`),
  CONSTRAINT `FKoj7jm8jqriqywdmxf4xkw6et2` FOREIGN KEY (`closet_id`) REFERENCES `closets` (`closet_id`)
) ENGINE=InnoDB AUTO_INCREMENT=511 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clothes`
--

LOCK TABLES `clothes` WRITE;
/*!40000 ALTER TABLE `clothes` DISABLE KEYS */;
INSERT INTO `clothes` VALUES (445,'RED','2024-08-14 01:25:49.000000','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'Rack 1','빨래 시 손세탁 권장!',1,'다홍빛 체크 블라우스','BLANK','DEFAULT','M','BLOUSE','2024-08-14 05:08:06.712507',12,212),(446,'BLUE','2024-08-14 01:25:49.000000','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'Rack 1','가벼운 세탁기로 세탁 가능',2,'단색 블루 가디건','BLANK','AUTUMN','L','CARDIGAN','2024-08-14 05:08:30.197611',6,212),(447,'GREEN','2024-08-14 01:25:49.000000','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'Rack 1','드라이클리닝 권장',3,'녹색 코트','BLANK','WINTER','XL','COAT','2024-08-14 05:10:27.497502',3,212),(448,'RED','2024-08-14 01:26:53.000000','http://example.com/image11.jpg',_binary '',NULL,'Rack 1','빨래 시 손세탁 권장',1,'체크 무늬 블라우스','CHECK','SPRING','M','BLOUSE','2024-08-14 06:02:54.269539',12,211),(449,'BLUE','2024-08-14 01:26:53.000000','http://example.com/image12.jpg',_binary '',NULL,'Rack 1','가벼운 세탁기로 세탁 가능',2,'단색 블루 가디건','BLANK','AUTUMN','L','CARDIGAN','2024-08-14 07:50:39.593562',6,211),(450,'GREEN','2024-08-14 01:26:53.000000','http://example.com/image13.jpg',_binary '',NULL,'Rack 1','드라이클리닝 권장',3,'녹색 코트','BLANK','WINTER','XL','COAT','2024-08-14 13:21:18.509551',3,211),(460,'GREEN','2024-08-14 01:42:09.118625','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '','2024-08-14',NULL,'데이트룩',NULL,'초록색 원피스','DOT','SUMMER','M','DRESS','2024-08-14 05:11:32.808886',1,212),(463,'RED','2024-08-14 05:11:15.710179','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'A1','',NULL,NULL,'DOT','DEFAULT','','DRESS','2024-08-14 05:11:58.833754',0,212),(464,'YELLOW','2024-08-14 05:11:22.015148','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'A1','',NULL,NULL,'DOT','DEFAULT','','DRESS','2024-08-14 05:14:07.769510',0,212),(465,'WHITE','2024-08-14 05:11:27.016560','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'A1','',NULL,NULL,'DOT','DEFAULT','','DRESS','2024-08-14 05:17:48.236179',0,212),(466,'WHITE','2024-08-14 05:17:58.342564','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'A1','',NULL,NULL,'DOT','DEFAULT','','DRESS','2024-08-14 05:19:26.693499',0,212),(467,'WHITE','2024-08-14 05:17:59.008045','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'A1','',NULL,NULL,'DOT','DEFAULT','','DRESS','2024-08-14 05:19:33.112697',0,212),(468,'WHITE','2024-08-14 05:17:59.661351','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'A1','',NULL,NULL,'DOT','DEFAULT','','DRESS','2024-08-14 05:19:35.472155',0,212),(469,'WHITE','2024-08-14 05:19:38.182540','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'A1','',NULL,NULL,'DOT','DEFAULT','','DRESS','2024-08-14 05:20:08.219683',0,212),(470,'GREEN','2024-08-14 05:19:43.966084','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'A1','',NULL,NULL,'DOT','DEFAULT','','DRESS','2024-08-14 05:20:09.852183',0,212),(471,'BLUE','2024-08-14 05:19:49.154735','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'A1','',NULL,NULL,'DOT','DEFAULT','','DRESS','2024-08-14 05:20:11.848983',0,212),(472,'RED','2024-08-14 05:19:53.648453','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'A1','',NULL,NULL,'DOT','DEFAULT','','DRESS','2024-08-14 05:30:53.105398',0,212),(473,'PINK','2024-08-14 05:19:58.028626','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'A1','',NULL,NULL,'DOT','DEFAULT','','DRESS','2024-08-14 05:36:11.780623',0,212),(474,'BROWN','2024-08-14 05:20:04.932466','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'A1','',NULL,NULL,'DOT','DEFAULT','','DRESS','2024-08-14 05:36:15.271595',0,212),(475,'RED','2024-08-14 05:35:18.615497','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'A1','',NULL,NULL,'DOT','DEFAULT','','DRESS','2024-08-14 05:42:41.555515',0,212),(476,'YELLOW','2024-08-14 05:35:24.842010','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'A1','',NULL,NULL,'DOT','DEFAULT','','DRESS','2024-08-14 05:42:58.290864',0,212),(477,'BLACK','2024-08-14 06:03:25.629392','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/1161931032322432',_binary '\0','2024-08-04','A1','운동용',11619310323224322,'아디다스 반바지','BLANK','SUMMER','라지','PANTS','2024-08-15 12:08:04.169631',3,212),(478,'GREEN','2024-08-14 06:03:26.523153','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '\0','2024-08-01','A1','데이트용',NULL,NULL,'DOT','SUMMER','M','DRESS','2024-08-15 16:42:24.922577',2,212),(479,'BLUE','2024-08-14 06:05:08.626866','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '\0','2024-08-04','A1','',NULL,'파란색 점퍼','ETC','WINTER','','JUMPER','2024-08-14 06:05:08.626866',2,212),(480,'BLUE','2024-08-14 06:05:14.041423','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '\0','2024-08-14','A1','좋아하는 티셔츠',1161931032322432,'챔피언 파란색 티셔츠','ETC','SUMMER','L','TSHIRT','2024-08-14 06:05:14.041423',3,212),(481,'YELLOW','2024-08-14 06:05:23.251617','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '',NULL,'A1','',NULL,NULL,'DOT','DEFAULT','','DRESS','2024-08-15 14:28:13.301131',0,212),(487,'RED','2024-08-14 13:34:37.000000',NULL,_binary '',NULL,'A1','메모1',NULL,'닉네임1','DOT','DEFAULT','','DRESS','2024-08-15 06:54:07.199702',0,217),(488,'BLUE','2024-08-14 13:34:37.000000',NULL,_binary '\0',NULL,'A1','메모2',NULL,'닉네임2','BLANK','DEFAULT','','TSHIRT','2024-08-14 13:34:37.000000',0,217),(489,'GREEN','2024-08-14 13:34:37.000000',NULL,_binary '\0',NULL,'A1','메모3',NULL,'닉네임3','CHECK','DEFAULT','','TSHIRT','2024-08-14 13:34:37.000000',0,217),(490,'BLACK','2024-08-14 13:34:37.000000',NULL,_binary '\0',NULL,'A1','메모4',NULL,'닉네임4','DOT','DEFAULT','','SKIRT','2024-08-14 13:34:37.000000',0,217),(491,'YELLOW','2024-08-14 13:34:37.000000',NULL,_binary '\0',NULL,'A1','메모5',NULL,'닉네임5','DOT','DEFAULT','','SKIRT','2024-08-14 13:34:37.000000',0,217),(493,'BLUE','2024-08-14 16:07:47.000000','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/444201429597128',_binary '\0','2024-08-15','B3','기능성 운동복',444201429597128,'챔피온 파란 티셔츠','BLANK','SUMMER','라지','TSHIRT','2024-08-15 18:55:59.611140',4,181),(494,'BROWN','2024-08-14 16:58:59.000000','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/410343409597128',_binary '\0','2024-08-10','A2','2023년 9월 nc백화점 구매',4103434095971283,'공유 가디건','CHECK','AUTUMN','엑스라지','CARDIGAN','2024-08-15 18:15:15.965974',0,212),(495,'BLACK','2024-08-15 02:45:15.000000','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/4186140429597128',_binary '\0','2024-08-02','A2','중성세제, 찬물에 단독세탁할 것!',4186140429597128,'블랙 꽃무늬 블라우스','PLANTS','SUMMER','M','BLOUSE','2024-08-15 17:27:36.712546',0,212),(496,'YELLOW','2024-08-15 07:53:17.563579','',_binary '\0',NULL,'','',NULL,NULL,'BLANK','DEFAULT','','JUMPSUITE','2024-08-15 07:53:17.563579',0,222),(497,'YELLOW','2024-08-15 07:58:25.048313','',_binary '\0',NULL,'N12','',NULL,NULL,'STRIPE','DEFAULT','','TSHIRT','2024-08-15 07:58:25.048313',0,222),(498,'BLACK','2024-08-15 16:00:05.000000','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/4192240499597128',_binary '\0','2024-08-15',NULL,NULL,4192240499597128,'검정색 치마','ETC',NULL,NULL,'SKIRT',NULL,1,181),(500,'WHITE','2024-08-15 16:48:34.000000',NULL,_binary '\0',NULL,'A1','메모1',44420,NULL,'DOT','DEFAULT','','TSHIRT','2024-08-15 19:09:33.255546',0,226),(501,'PINK','2024-08-15 16:48:34.000000',NULL,_binary '\0',NULL,'A1','메모2',44421,NULL,'DOT','DEFAULT',NULL,'DRESS','2024-08-15 16:48:34.000000',0,226),(502,'YELLOW','2024-08-15 16:48:34.000000',NULL,_binary '\0',NULL,'A1','메모3',44422,NULL,'DOT','DEFAULT',NULL,'BLOUSE','2024-08-15 16:48:34.000000',0,226),(503,'RED','2024-08-15 16:48:34.000000',NULL,_binary '\0',NULL,'A1','메모4',44423,NULL,'DOT','DEFAULT',NULL,'PANTS','2024-08-15 16:48:34.000000',0,226),(504,'WHITE','2024-08-15 17:03:25.000000',NULL,_binary '\0',NULL,'A1','메모1',44420,NULL,'DOT','DEFAULT',NULL,'TSHIRT','2024-08-15 17:03:25.000000',0,225),(505,'PINK','2024-08-15 17:03:25.000000',NULL,_binary '\0',NULL,'A1','메모2',44421,NULL,'DOT','DEFAULT',NULL,'JUMPSUITE','2024-08-15 17:03:25.000000',0,225),(506,'YELLOW','2024-08-15 17:03:25.000000',NULL,_binary '\0',NULL,'A1','메모3',44422,NULL,'DOT','DEFAULT',NULL,'DRESS','2024-08-15 17:03:25.000000',0,225),(507,'RED','2024-08-15 17:03:25.000000',NULL,_binary '\0',NULL,'A1','메모4',44423,NULL,'DOT','DEFAULT',NULL,'BLOUSE','2024-08-15 17:03:25.000000',0,225),(508,'YELLOW','2024-08-15 18:03:42.076698','',_binary '\0',NULL,'A17','이염 주의',NULL,'산뜻한 노랑셔츠','BLANK','SPRING','라지','SHIRT','2024-08-15 18:04:09.570506',0,212),(509,'BLACK','2024-08-15 22:27:57.000000','https://closetoyoubucket.s3.ap-northeast-2.amazonaws.com/4186140429597128',_binary '\0','2024-08-15','A3',NULL,410343409597128,'블랙 꽃무늬 블라우스','PLANTS',NULL,NULL,'BLOUSE','2024-08-15 18:04:09.570506',1,181);
/*!40000 ALTER TABLE `clothes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16 11:52:14
