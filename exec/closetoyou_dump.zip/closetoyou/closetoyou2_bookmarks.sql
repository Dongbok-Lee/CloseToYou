-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11b201.p.ssafy.io    Database: closetoyou2
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bookmarks`
--

DROP TABLE IF EXISTS `bookmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookmarks` (
  `bookmark_id` bigint NOT NULL AUTO_INCREMENT,
  `created_date_time` datetime(6) DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `update_date_time` datetime(6) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`bookmark_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookmarks`
--

LOCK TABLES `bookmarks` WRITE;
/*!40000 ALTER TABLE `bookmarks` DISABLE KEYS */;
INSERT INTO `bookmarks` VALUES (1,'2024-08-12 01:18:47.940698',_binary '','내가 자주 입는 옷들','2024-08-12 07:10:34.763090',13),(2,'2024-08-12 07:08:54.160100',_binary '','데이트룩 하투','2024-08-12 07:21:00.586288',13),(3,'2024-08-12 07:29:55.992227',_binary '','ㄴㄴㄴ','2024-08-12 18:09:28.559050',13),(4,'2024-08-12 07:30:57.229028',_binary '\0','토 할 것 같아','2024-08-13 04:25:27.521003',13),(5,'2024-08-12 14:13:52.054716',_binary '','새로운 코디','2024-08-12 14:14:53.302688',13),(6,'2024-08-12 17:27:09.549302',_binary '','너무 피곤해..','2024-08-12 17:27:13.615597',13),(7,'2024-08-12 17:53:38.210810',_binary '','안녕','2024-08-13 01:00:59.386254',13),(8,'2024-08-12 18:14:18.684106',_binary '\0','살려줘ㅠㅠㅠㅠ','2024-08-12 18:21:49.147033',13),(9,'2024-08-12 18:18:01.953116',_binary '','','2024-08-12 18:18:07.979840',13),(10,'2024-08-12 18:19:55.608022',_binary '','벌써 3시라니','2024-08-13 04:22:37.615533',13),(11,'2024-08-12 18:21:56.946638',_binary '','죽이던가..','2024-08-13 01:20:57.250440',13),(12,'2024-08-13 01:00:35.765978',_binary '','새로운 코디 변경','2024-08-13 04:24:12.882249',13),(13,'2024-08-13 04:22:44.667388',_binary '\0','지금은 벌써 1시 반..','2024-08-13 04:22:44.667388',13),(14,'2024-08-13 04:23:01.604320',_binary '\0','할 일이 너무 많아요','2024-08-13 05:31:34.051900',13),(15,'2024-08-13 04:24:15.518863',_binary '','집에 갈래..','2024-08-13 04:31:13.857752',13),(16,'2024-08-13 04:31:08.014414',_binary '\0','안뇽','2024-08-13 04:31:08.014414',13),(17,'2024-08-14 03:44:12.291242',_binary '\0','마이클 코디','2024-08-14 05:29:59.267966',16),(18,'2024-08-14 03:44:15.094791',_binary '\0','ㅇㄻㄴ','2024-08-14 03:44:23.147126',16),(19,'2024-08-14 03:44:16.165018',_binary '','','2024-08-14 03:44:18.890581',16),(20,'2024-08-14 06:07:16.495660',_binary '','','2024-08-14 17:38:21.050884',17),(21,'2024-08-14 06:33:56.781433',_binary '','hdfhdj','2024-08-15 05:34:17.336767',16),(22,'2024-08-14 17:38:07.926547',_binary '','꾸안꾸','2024-08-14 18:28:34.857579',17),(23,'2024-08-14 17:38:30.489016',_binary '\0','운동할때 입는 옷','2024-08-15 18:06:59.646213',17),(24,'2024-08-14 18:21:37.785189',_binary '\0','쿨톤 계열','2024-08-15 17:11:22.864212',17),(25,'2024-08-15 05:29:59.901457',_binary '','새로운 코디','2024-08-15 05:33:35.835864',15),(26,'2024-08-15 05:30:02.058665',_binary '','','2024-08-15 05:33:33.240203',15),(27,'2024-08-15 05:30:10.682365',_binary '\0','ㅎㅎ','2024-08-15 05:30:10.682365',15),(28,'2024-08-15 05:30:15.573599',_binary '\0','내 코디','2024-08-15 18:04:02.157294',15),(29,'2024-08-15 05:33:40.943811',_binary '\0','안녕','2024-08-15 05:33:40.943811',15),(30,'2024-08-15 05:33:47.136214',_binary '\0','안녕1','2024-08-15 05:33:47.136214',15),(31,'2024-08-15 05:33:52.007384',_binary '\0','안녕~!','2024-08-15 05:33:52.007384',15),(32,'2024-08-15 05:36:49.564191',_binary '\0','gg','2024-08-15 05:36:49.564191',15),(33,'2024-08-15 14:18:34.259331',_binary '','Hue','2024-08-15 14:18:36.390159',17),(34,'2024-08-15 16:50:26.176846',_binary '\0','마이클 코디 테스트','2024-08-15 16:50:38.029889',23),(35,'2024-08-15 18:05:29.005578',_binary '\0','하객룩','2024-08-15 18:05:54.011063',17);
/*!40000 ALTER TABLE `bookmarks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16 11:52:13
